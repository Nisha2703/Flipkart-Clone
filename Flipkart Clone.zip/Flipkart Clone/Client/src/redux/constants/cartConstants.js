

export const ADD_TO_CART = "addToCart"
export const REMOVE_FROM_CART = "removeFromCart"
export const ADD_TO_CART_ERROR = "cartReset"
export const UPDATE_QUANTITY_TO_CART='updatequantity'



export const CHECKOUT_FROM_CART = "checkoutFromCart"
export const CHECKOUT_FROM_PRODUCT='checkoutFromProduct'
