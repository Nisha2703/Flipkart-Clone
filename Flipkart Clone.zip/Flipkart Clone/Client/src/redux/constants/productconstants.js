

export const GET_PRODUCT_SUCCESS = 'getProductsSuccess';
export const GET_PRODUCT_FAIL = 'getProductsFail';


export const GET_PRODUCT_DETAIL_REQUEST= 'getProductDetailRequest';
export const GET_PRODUCT_DETAIL_SUCCESS= 'getProductDetailSuccess';
export const GET_PRODUCT_DETAIL_RESET= 'getProductDetailReset';
export const GET_PRODUCT_DETAIL_FAIL= 'getProductDetailFail';
